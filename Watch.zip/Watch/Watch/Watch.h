#include"CString.h"
#include"Date.h"
#include"Time.h"
class Watch
{
private:
	CString msg = "WELCOME";
	Date dt;
	Time tm;
public:
	void massageDisplay();
	void setHour(int h);
	void setMinute(int m);
	void setSecond(int s);
	void setTime(int h, int m, int s);
	int getHour();
	int getMinute();
	int getSecond();
	void printTwentyFourHourFormat();
	void printTwelveHourFormat();
	void incHour(int h);
	void incMin(int m);
	void incSec(int s);
	void setDay(int d);
	void setMonth(int m);
	void setYear(int y);
	void setData(int d, int m, int y);
	int getDay();
	int getMonth();
	int getYear();
	void ddmmyyFormat();
	void incDay(int d);
	void incMonth(int m);
	void incYear(int y);
};
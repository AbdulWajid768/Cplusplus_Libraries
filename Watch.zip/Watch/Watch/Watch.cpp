#include"Watch.h"
void Watch::massageDisplay()
{
	msg.display();
}
void Watch::setHour(int h)
{
	tm.setHour(h);
}
void Watch::setMinute(int m)
{
	tm.setMinute(m);
}
void Watch::setSecond(int s)
{
	tm.setSecond(s);
}
void Watch::setTime(int h, int m, int s)
{
	tm.setTime(h, m, s);

}
int Watch::getHour()
{
	return tm.getHour();
}
int Watch::getMinute()
{
	return tm.getMinute();
}
int Watch::getSecond()
{
	return tm.getSecond();
}
void Watch::printTwentyFourHourFormat()
{
	massageDisplay();
	tm.printTwentyFourHourFormat();
}
void Watch::printTwelveHourFormat()
{
	massageDisplay();
	tm.printTwelveHourFormat();
}
void Watch::incHour(int h = 1)
{
	tm.incHour(h);
}
void Watch::incMin(int m = 1)
{
	tm.incMin(m);
}
void Watch::incSec(int s = 1)
{
	tm.incSec(s);
}
void Watch::setDay(int d)
{
	dt.setDay(d);
}
void Watch::setMonth(int m)
{
	dt.setMonth(m);
}
void Watch::setYear(int y)
{
	dt.setYear(y);
}
void Watch::setData(int d, int m, int y)
{
	dt.setDate(d, m, y);
}
int Watch::getDay()
{
	return dt.getDay();
}
int Watch::getMonth()
{
	return dt.getMonth();
}
int Watch::getYear()
{
	return dt.getYear();
}
void Watch::ddmmyyFormat()
{
	massageDisplay();
	dt.ddmmyyFormat();
}
void Watch::incDay(int d = 1)
{
	dt.incDay(d);
}
void Watch::incMonth(int m = 1)
{
	dt.incMonth(m);
}
void Watch::incYear(int y = 1)
{
	dt.incYear(y);
}















































//int sum(int argc, ...)
//{
//	int sum = 0;
//	va_list vl;
//	__crt_va_start(vl, argc);
//	cout << __crt_va_arg(vl, int) << endl;
//	cout << __crt_va_arg(vl, int) << endl;
//	cout << __crt_va_arg(vl, int) << endl;
//	cout << __crt_va_arg(vl, int) << endl;
//	cout << __crt_va_arg(vl, int) << endl;
//	__crt_va_end(vl);
//	return sum;
//}
//void main()
//{
//	cout << sum(5, 1, 2, 3, 4, 5) << endl;
//}
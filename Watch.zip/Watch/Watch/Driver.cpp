#include<iostream>
#include"Watch.h"
using namespace std;
void main()
{
	Watch w;
	w.ddmmyyFormat();
	w.incMonth(12);
	w.ddmmyyFormat();
	w.incDay(36500);
	w.ddmmyyFormat();
	w.printTwelveHourFormat();
}